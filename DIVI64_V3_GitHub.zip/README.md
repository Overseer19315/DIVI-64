# DIVI64 CENTRAL MAINFRAME V3

GitHub Pages-ready files for the current DIVI64 V3 browser prototype.

Files:
- index.html
- style.css
- script.js

Default accounts:
- D-64-ADM-01 / D64-Admin-7Kp!
- D-64-ADM-02 / D64-Exec-4Qm!
- D-64-001 / D64-P01-X7v!
- D-64-002 / D64-P02-N3k!
- D-64-003 / D64-P03-R8t!
- D-64-004 / D64-P04-L5q!
- D-64-005 / D64-P05-W9c!
- D-64-006 / D64-P06-H2m!
- D-64-007 / D64-P07-F6p!
- D-64-008 / D64-P08-J4s!
- D-64-009 / D64-P09-B7x!
- D-64-010 / D64-P10-V3n!

IMPORTANT: this is still a client-side prototype. Credentials and state are in browser JavaScript/localStorage. Do not use it as secure production authentication or a real shared multi-user database.
